package com.flutterflow.testapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
