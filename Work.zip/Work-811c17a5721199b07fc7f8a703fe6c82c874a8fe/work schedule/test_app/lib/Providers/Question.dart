
import 'Option.dart';
import '../models/SingleQuestion.dart';
class Question {
   static List<SingleQuestion>questions=[
    SingleQuestion( id:"1",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),
        SingleQuestion( id:"2",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),
        SingleQuestion( id:"3",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),
        SingleQuestion( id:"4",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),
        SingleQuestion( id:"5",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),
        SingleQuestion( id:"6",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),
        SingleQuestion( id:"7",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),
        SingleQuestion( id:"8",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),
        SingleQuestion( id:"9",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),
        SingleQuestion( id:"10",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),
        SingleQuestion( id:"11",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),
        SingleQuestion( id:"12",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),
        SingleQuestion( id:"13",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),
        SingleQuestion( id:"14",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),
        SingleQuestion( id:"15",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),
        SingleQuestion( id:"16",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),
        SingleQuestion( id:"17",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),
        SingleQuestion( id:"18",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),
        SingleQuestion( id:"19",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),
        SingleQuestion( id:"20",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),
        SingleQuestion( id:"21",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),
        SingleQuestion( id:"22",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),
        SingleQuestion( id:"23",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),
        SingleQuestion( id:"24",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),
        SingleQuestion( id:"25",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),
        SingleQuestion( id:"26",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),
        SingleQuestion( id:"27",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),
        SingleQuestion( id:"28",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),
        SingleQuestion( id:"29",question: "I am introvert.",
        options:[
          Option(optionId: 1,optionTitle: "Agree",marks:1,),
          Option(optionId: 2,optionTitle: "Slightly Agree",marks:2,),
          Option(optionId: 3,optionTitle: "Slightly Disagree",marks:3,),
          Option(optionId: 4,optionTitle: "Disagree",marks:4,),],
        ),

       

  ];
  static List<SingleQuestion> get testQuestions{
    return [...questions];
   }
   static SingleQuestion  findById(String id){
     SingleQuestion answer =SingleQuestion(id: "null",
         question:"Not Available",options: []);
      for(int i=0;i<questions.length;i++){
        if(questions[i].id==id)answer= questions[i];
      }
      return answer;
   }
   void deSelectOptions(String questionId){
      SingleQuestion quest=findById(questionId);
      for(int i=0;i<quest.options.length;i++){


      }

   }
   int selectedOption(String questionId){
    int index=-1;
     SingleQuestion quest=findById(questionId);
     for(int i=0;i<quest.options.length;i++){


     }
    return index;
   }
}